package com.hbe.hanback.iotbluetooth;

import java.io.InputStream;import java.io.OutputStream;

import java.util.ArrayList;
import java.util.List;import java.util.Set;
import java.util.UUID;


import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends Activity {
    static final int REQUEST_ENABLE_BT = 10;
    int mPariedDeviceCount = 0;
    Set<BluetoothDevice> mDevices;

    BluetoothAdapter mBluetoothAdapter;

    BluetoothDevice mRemoteDevie;
    BluetoothSocket mSocket = null;
    OutputStream mOutputStream = null;
    InputStream mInputStream = null;
    String mStrDelimiter = "\r";
    char mCharDelimiter = '\r';

    boolean isMain;

    Thread mWorkerThread = null;
    byte[] readBuffer;
    int readBufferPosition;


    Button LEDON, LEDOFF, DCMON, DCMOFF, STMON, LSON, LSOFF, BUZON, BUZOFF, REDON, REDOFF, GREENON, GREENOFF, BLUEON, BLUEOFF, RELAYON, RELAYOFF;
    ImageView LED,DCM,STM,PIR,US,TEMP,TEMP_ov, CDS, SOUND, HUMI,HUMI_ov, VR, SW, TOUCH,PD,BUMP,OD,LS,MERC,TILT,FLAME,REED,BUZ, RED, GREEN, BLUE, RELAY, IRT, LIMIT, KNOCK, DUST, GAS, SOIL, THERM, AT;
    TextView US_val, TEMP_val, SOUND_val, HUMI_val,VR_val, DUST_val, SOIL_val, GAS_val, THERM_val, AT_val;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        {
            int widthpx = dm.widthPixels;
            int heightpx = dm.heightPixels;
            float widthdpi = dm.xdpi;
            float heightdpi = dm.ydpi;
            final float displaySize = (float)Math.sqrt((float) Math.pow(widthpx/widthdpi,2)+(float)Math.pow(heightpx/heightdpi,2));

            setContentView(R.layout.home);

            ImageView MAIN = (ImageView)findViewById(R.id.Main);
            ImageView ADDON = (ImageView)findViewById(R.id.Addon);

            MAIN.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View v) {
                    if(displaySize>=6.0)
                        setContentView(R.layout.activity_main_6in_over);
                    else
                        setContentView(R.layout.activity_main_6in_under);

                    isMain=true;
                    Init_Main();
                }
            });

            ADDON.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View v) {
                    if(displaySize>=6.0)
                        setContentView(R.layout.activity_sub_6in_over);
                    else
                        setContentView(R.layout.activity_sub_6in_under);

                    isMain=false;
                    Init_Sub();
                }
            });

        }
    }


    void Init_Main(){
        LEDON = (Button)findViewById(R.id.LEDON);
        LEDOFF = (Button)findViewById(R.id.LEDOFF);
        LED=(ImageView)findViewById(R.id.LED);
        DCMON = (Button)findViewById(R.id.DCMON);
        DCMOFF = (Button)findViewById(R.id.DCMOFF);
        DCM=(ImageView)findViewById(R.id.DCM);
        STMON = (Button)findViewById(R.id.STMON);
        STM=(ImageView)findViewById(R.id.STM);
        PIR=(ImageView)findViewById(R.id.PIR);
        US_val = (TextView) findViewById(R.id.US_val);
        US=(ImageView)findViewById(R.id.US);
        TEMP_val = (TextView) findViewById(R.id.TEMP_val);
        TEMP=(ImageView)findViewById(R.id.TEMP);
        TEMP_ov=(ImageView)findViewById(R.id.TEMP_ov);
        CDS=(ImageView)findViewById(R.id.CDS);
        SOUND_val = (TextView) findViewById(R.id.SOUND_val);
        SOUND=(ImageView)findViewById(R.id.SOUND);
        HUMI_val = (TextView) findViewById(R.id.HUMI_val);
        HUMI=(ImageView)findViewById(R.id.HUMI);
        HUMI_ov=(ImageView)findViewById(R.id.HUMI_ov);
        VR_val = (TextView) findViewById(R.id.VR_val);
        VR=(ImageView)findViewById(R.id.VR);
        SW=(ImageView)findViewById(R.id.SW);
        TOUCH=(ImageView)findViewById(R.id.TOUCH);
        PD=(ImageView)findViewById(R.id.PD);
        BUMP=(ImageView)findViewById(R.id.BUMP);
        OD=(ImageView)findViewById(R.id.OD);
        LSON = (Button)findViewById(R.id.LSON);
        LSOFF = (Button)findViewById(R.id.LSOFF);
        LS=(ImageView)findViewById(R.id.LS);
        MERC=(ImageView)findViewById(R.id.MERC);
        TILT=(ImageView)findViewById(R.id.TILT);
        FLAME=(ImageView)findViewById(R.id.FLAME);
        REED=(ImageView)findViewById(R.id.REED);
        BUZON = (Button)findViewById(R.id.BUZON);
        BUZOFF = (Button)findViewById(R.id.BUZOFF);
        BUZ=(ImageView)findViewById(R.id.BUZ);

        LEDON.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("LEDON");
                LED.setImageResource(R.drawable.led_on);
            }
        });

        LEDOFF.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("LEDOFF");
                LED.setImageResource(R.drawable.led_off);
            }
        });

        DCMON.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("DCMON");
                DCM.setImageResource(R.drawable.dcm_on);
            }
        });

        DCMOFF.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("DCMOFF");
                DCM.setImageResource(R.drawable.dcm_off);
            }
        });

        STMON.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("STMON");
            }
        });

        LSON.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("LASERON");
                LS.setImageResource(R.drawable.laser_on);
            }
        });

        LSOFF.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("LASEROFF");
                LS.setImageResource(R.drawable.laser_off);
            }
        });

        BUZON.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("BUZZERON");
                BUZ.setImageResource(R.drawable.buz_on);
            }
        });

        BUZOFF.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("BUZZEROFF");
                BUZ.setImageResource(R.drawable.buz_off);
            }
        });

        checkBluetooth();
    }


    void Init_Sub(){
        REDON = (Button)findViewById(R.id.REDON);
        REDOFF = (Button)findViewById(R.id.REDOFF);
        RED = (ImageView)findViewById(R.id.RED);
        GREENON = (Button)findViewById(R.id.GREENON);
        GREENOFF = (Button)findViewById(R.id.GREENOFF);
        GREEN = (ImageView)findViewById(R.id.GREEN);
        BLUEON = (Button)findViewById(R.id.BLUEON);
        BLUEOFF = (Button)findViewById(R.id.BLUEOFF);
        BLUE = (ImageView)findViewById(R.id.BLUE);
        RELAYON = (Button)findViewById(R.id.RELAYON);
        RELAYOFF = (Button)findViewById(R.id.RELAYOFF);
        RELAY = (ImageView)findViewById(R.id.RELAY);
        IRT = (ImageView)findViewById(R.id.IRT);
        LIMIT = (ImageView)findViewById(R.id.LIMIT);
        KNOCK = (ImageView)findViewById(R.id.KNOCK);
        DUST_val = (TextView)findViewById(R.id.DUST_val);
        DUST = (ImageView)findViewById(R.id.DUST);
        SOIL_val = (TextView)findViewById(R.id.SOIL_val);
        SOIL = (ImageView)findViewById(R.id.SOIL);
        GAS_val = (TextView)findViewById(R.id.GAS_val);
        GAS = (ImageView)findViewById(R.id.GAS);
        THERM_val = (TextView)findViewById(R.id.THERM_val);
        THERM = (ImageView)findViewById(R.id.THERM);
        AT_val = (TextView)findViewById(R.id.AT_val);
        AT = (ImageView)findViewById(R.id.AT);

        REDON.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("REDON");
                RED.setImageResource(R.drawable.rgb_r);
            }
        });

        REDOFF.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("REDOFF");
                RED.setImageResource(R.drawable.rgb_off);
            }
        });

        GREENON.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("GREENON");
                GREEN.setImageResource(R.drawable.rgb_g);
            }
        });

        GREENOFF.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("GREENOFF");
                GREEN.setImageResource(R.drawable.rgb_off);
            }
        });

        BLUEON.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("BLUEON");
                BLUE.setImageResource(R.drawable.rgb_b);
            }
        });

        BLUEOFF.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("BLUEOFF");
                BLUE.setImageResource(R.drawable.rgb_off);
            }
        });

        RELAYON.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("RELAYON");
                RELAY.setImageResource(R.drawable.relay_on);
            }
        });

        RELAYOFF.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                sendData("RELAYOFF");
                RELAY.setImageResource(R.drawable.relay_off);
            }
        });

        checkBluetooth();
    }


    BluetoothDevice getDeviceFromBondedList(String name) {
        BluetoothDevice selectedDevice = null;

        for(BluetoothDevice deivce : mDevices) {
            if(name.equals(deivce.getName())) {
                selectedDevice = deivce;
                break;
            }
        }
        return selectedDevice;
    }

    String sendData(String msg) {
        String data = null;

        try{
            mOutputStream.write(msg.getBytes());

            readBufferPosition = 0;
            readBuffer = new byte[1024];

            try {
                while(mInputStream.available()<=0);

                int byteAvailable = mInputStream.available();
                if(byteAvailable > 0) {
                    byte[] packetBytes = new byte[byteAvailable];

                    mInputStream.read(packetBytes);

                    String k = Integer.toString(byteAvailable);
                    for(int i=0; i<byteAvailable; i++) {
                        byte b = packetBytes[i];
                        if(b == mCharDelimiter) {
                            byte[] encodedBytes = new byte[readBufferPosition];
                            System.arraycopy(readBuffer, 0, encodedBytes, 0, encodedBytes.length);

                            data = new String(encodedBytes, "US-ASCII");
                            readBufferPosition = 0;
                        }
                        else {
                            readBuffer[readBufferPosition++] = b;
                        }
                    }
                }

            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Error occured on receiving data.", Toast.LENGTH_LONG).show();
                finish();
            }
        }catch(Exception e) {
            Toast.makeText(getApplicationContext(), "Error occured on transmitting data.", Toast.LENGTH_LONG).show();
            finish();
        }

        return data;
    }

    void connectToSelectedDevice(String selectedDeviceName) {
        mRemoteDevie = getDeviceFromBondedList(selectedDeviceName);
        UUID uuid = java.util.UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

        try {
            mSocket = mRemoteDevie.createRfcommSocketToServiceRecord(uuid);
            mSocket.connect();

            mOutputStream = mSocket.getOutputStream();
            mInputStream = mSocket.getInputStream();



            final Handler loop_processing = new Handler();

            Runnable loop_Main = new Runnable() {
                @Override
                public void run() {
                    String returned_Value = sendData("PIR");

                    if(returned_Value.equals("Y")){
                        PIR.setImageResource(R.drawable.pir_on);
                    }else{
                        PIR.setImageResource(R.drawable.pir_off);
                    }

                    returned_Value = sendData("LIGHT");

                    if(returned_Value.equals("Y")){
                        CDS.setImageResource(R.drawable.cds_on);
                    }else{
                        CDS.setImageResource(R.drawable.cds_off);
                    }

                    returned_Value = sendData("SW");

                    if(returned_Value.equals("Y")){
                        SW.setImageResource(R.drawable.sw_on);
                    }else{
                        SW.setImageResource(R.drawable.sw_off);
                    }

                    returned_Value = sendData("TOUCH");

                    if(returned_Value.equals("Y")){
                        TOUCH.setImageResource(R.drawable.touch_on);
                    }else{
                        TOUCH.setImageResource(R.drawable.touch_off);
                    }

                    returned_Value = sendData("PD");

                    if(returned_Value.equals("Y")){
                        PD.setImageResource(R.drawable.pd_on);
                    }else{
                        PD.setImageResource(R.drawable.pd_off);
                    }

                    returned_Value = sendData("BUMP");

                    if(returned_Value.equals("Y")){
                        BUMP.setImageResource(R.drawable.bump_on);
                    }else{
                        BUMP.setImageResource(R.drawable.bump_off);
                    }

                    returned_Value = sendData("IRO");

                    if(returned_Value.equals("Y")){
                        OD.setImageResource(R.drawable.od_on);
                    }else{
                        OD.setImageResource(R.drawable.od_off);
                    }

                    returned_Value = sendData("PIR");

                    if(returned_Value.equals("Y")){
                        PIR.setImageResource(R.drawable.pir_on);
                    }else{
                        PIR.setImageResource(R.drawable.pir_off);
                    }

                    returned_Value = sendData("US");
                    US_val.setText(returned_Value + "cm");
                    if(Integer.parseInt(returned_Value) >= 100) US.setImageResource(R.drawable.ultrasonic3);
                    else if(Integer.parseInt(returned_Value) >= 50) US.setImageResource(R.drawable.ultrasonic2);
                    else US.setImageResource(R.drawable.ultrasonic1);

                    returned_Value = sendData("TEMP");
                    if(!returned_Value.equals("-1")) {
                        TEMP_val.setText(returned_Value+"C");
                        TEMP_ov.setAlpha(0.5f-(Float.parseFloat(returned_Value)+20f)/50f/2f);
                    }

                    returned_Value = sendData("HUMI");
                    if(!returned_Value.equals("-1")) {
                        HUMI_val.setText(returned_Value+"%");
                        HUMI_ov.setAlpha(Integer.parseInt(returned_Value)/200f);
                    }

                    returned_Value = sendData("SOUND");
                    SOUND_val.setText(returned_Value);
                    SOUND.setAlpha((Integer.parseInt(returned_Value)/3000)/2+0.5f);

                    returned_Value = sendData("VR");
                    VR_val.setText(returned_Value);
                    VR.setRotation((Float.parseFloat(returned_Value)/4095)*90-90);//-90);

                    returned_Value = sendData("MERC");

                    if(returned_Value.equals("Y")){
                        MERC.setImageResource(R.drawable.mercury_on);
                    }else{
                        MERC.setImageResource(R.drawable.mercury_off);
                    }

                    returned_Value = sendData("TILT");

                    if(returned_Value.equals("Y")){
                        TILT.setImageResource(R.drawable.tilt_on);
                    }else{
                        TILT.setImageResource(R.drawable.tilt_off);
                    }

                    returned_Value = sendData("FLAME");

                    if(returned_Value.equals("Y")){
                        FLAME.setImageResource(R.drawable.flame_on);
                    }else{
                        FLAME.setImageResource(R.drawable.flame_off);
                    }

                    returned_Value = sendData("REED");

                    if(returned_Value.equals("Y")){
                        REED.setImageResource(R.drawable.reed_on);
                    }else{
                        REED.setImageResource(R.drawable.reed_off);
                    }

                    loop_processing.postDelayed(this,500);
                }
            };

            Runnable loop_Sub = new Runnable() {
                @Override
                public void run() {
                    String returned_Value = sendData("IRT");

                    if(returned_Value.equals("Y")){
                        IRT.setImageResource(R.drawable.irt_on);
                    }else{
                        IRT.setImageResource(R.drawable.irt_off);
                    }

                    returned_Value = sendData("LIMIT");

                    if(returned_Value.equals("Y")){
                        LIMIT.setImageResource(R.drawable.limit_on);
                    }else{
                        LIMIT.setImageResource(R.drawable.limit_off);
                    }

                    returned_Value = sendData("KNOCK");

                    if(returned_Value.equals("Y")){
                        KNOCK.setImageResource(R.drawable.knock_on);
                    }else{
                        KNOCK.setImageResource(R.drawable.knock_off);
                    }

                    returned_Value = sendData("DUST");

                    DUST_val.setText(returned_Value);
                    DUST.setAlpha(0.2f+(Float.parseFloat(returned_Value))/4095f*0.8f);

                    returned_Value = sendData("SOIL");

                    SOIL_val.setText(returned_Value);
                    SOIL.setAlpha(0.2f+(Float.parseFloat(returned_Value))/4095f*0.8f);

                    returned_Value = sendData("GAS");

                    GAS_val.setText(returned_Value);
                    GAS.setAlpha(0.2f+(Float.parseFloat(returned_Value))/4095f*0.8f);

                    returned_Value = sendData("THERM");

                    THERM_val.setText(returned_Value);
                    THERM.setAlpha((float) (0.2f+(Float.parseFloat(returned_Value)+30)/80f*0.8f));

                    returned_Value = sendData("AT");

                    AT_val.setText(returned_Value);
                    AT.setAlpha(0.2f+(Float.parseFloat(returned_Value))/80f*0.8f);

                    loop_processing.postDelayed(this,500);
                }
            };

            if (isMain)
                loop_processing.postDelayed(loop_Main,500);
            else
                loop_processing.postDelayed(loop_Sub,500);

        }catch(Exception e) {
            Toast.makeText(getApplicationContext(), "Error occured on connecting bluetooth.", Toast.LENGTH_LONG).show();
            finish();
        }
    }



    void selectDevice() {
        mDevices = mBluetoothAdapter.getBondedDevices();
        mPariedDeviceCount = mDevices.size();

        if(mPariedDeviceCount == 0 ) {
            Toast.makeText(getApplicationContext(), "Can't find paired device.", Toast.LENGTH_LONG).show();
            finish();
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Device to connect.");


        List<String> listItems = new ArrayList<String>();
        for(BluetoothDevice device : mDevices) {
            listItems.add(device.getName());
        }
        listItems.add("Cancel");


        final CharSequence[] items = listItems.toArray(new CharSequence[listItems.size()]);
        listItems.toArray(new CharSequence[listItems.size()]);

        builder.setItems(items, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int item) {
                // TODO Auto-generated method stub
                if(item == mPariedDeviceCount) {
                    Toast.makeText(getApplicationContext(), "Doesn't selected device to connect.", Toast.LENGTH_LONG).show();
                    finish();
                }
                else {
                    connectToSelectedDevice(items[item].toString());
                }
            }

        });

        builder.setCancelable(false);
        AlertDialog alert = builder.create();
        alert.show();
    }


    void checkBluetooth() {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(mBluetoothAdapter == null ) {
            Toast.makeText(getApplicationContext(), "This Device didn't support bluetooth.", Toast.LENGTH_LONG).show();
            finish();
        }
        else {
            if(!mBluetoothAdapter.isEnabled()) {
                Toast.makeText(getApplicationContext(), "Bluetooth was disabled.", Toast.LENGTH_LONG).show();
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
            else
                selectDevice();
        }
    }


    @Override
    protected void onDestroy() {
        try{
            mWorkerThread.interrupt();
            mInputStream.close();
            mSocket.close();
        }catch(Exception e){}
        super.onDestroy();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch(requestCode) {
            case REQUEST_ENABLE_BT:
                if(resultCode == RESULT_OK) {
                    selectDevice();
                }
                else if(resultCode == RESULT_CANCELED) {
                    Toast.makeText(getApplicationContext(), "Bluetooth is not available.", Toast.LENGTH_LONG).show();
                    finish();
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}